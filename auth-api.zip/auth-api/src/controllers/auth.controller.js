const User = require('../models/User');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const { signToken, verifyToken } = require('../utils/token');
const otpService = require('../services/otp.service');

const GENERIC_OTP_MSG = 'If an account exists for this email, an OTP has been sent.';

// Sends an OTP only if it makes sense for the account; never reveals whether the account exists.
const dispatchOtp = async (email, purpose) => {
  const user = await User.findOne({ email });
  if (!user) return;
  if (purpose === 'email_verification' && user.isVerified) return;
  await otpService.sendOtp({ email, name: user.name, purpose });
};

// POST /api/auth/register
exports.register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;

  let user = await User.findOne({ email });
  if (user && user.isVerified) throw new AppError('An account with this email already exists', 409);

  if (user) {
    // Unverified leftover registration: refresh details and re-send OTP
    user.name = name;
    user.password = password;
    await user.save();
  } else {
    user = await User.create({ name, email, password });
  }

  await otpService.sendOtp({ email, name: user.name, purpose: 'email_verification' });

  res.status(201).json({
    success: true,
    message: 'Registration successful. An OTP has been sent to your email to verify your account.',
  });
});

// POST /api/auth/login
exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email }).select('+password');

  if (!user || !(await user.comparePassword(password))) {
    throw new AppError('Invalid email or password', 401);
  }
  if (!user.isVerified) {
    throw new AppError('Email not verified. Please verify your email with the OTP first.', 403);
  }

  res.json({ success: true, token: signToken(user.id), user });
});

// POST /api/auth/send-otp   and   POST /api/auth/resend-otp
// (resend uses the same logic; the per-email cooldown prevents abuse)
exports.sendOtp = asyncHandler(async (req, res) => {
  const { email, purpose = 'email_verification' } = req.body;
  await dispatchOtp(email, purpose);
  res.json({ success: true, message: GENERIC_OTP_MSG });
});

// POST /api/auth/verify-otp
exports.verifyOtp = asyncHandler(async (req, res) => {
  const { email, otp, purpose = 'email_verification' } = req.body;

  const user = await User.findOne({ email });
  if (!user) throw new AppError('Invalid or expired OTP', 400);

  await otpService.verifyOtp({ email, otp, purpose });

  if (purpose === 'email_verification') {
    user.isVerified = true;
    await user.save();
    return res.json({
      success: true,
      message: 'Email verified successfully',
      token: signToken(user.id),
      user,
    });
  }

  // password_reset: hand back a short-lived token usable only on /reset-password
  res.json({
    success: true,
    message: 'OTP verified. Use the resetToken to set a new password within 10 minutes.',
    resetToken: signToken(user.id, 'password_reset', '10m'),
  });
});

// POST /api/auth/forgot-password
exports.forgotPassword = asyncHandler(async (req, res) => {
  await dispatchOtp(req.body.email, 'password_reset');
  res.json({ success: true, message: GENERIC_OTP_MSG });
});

// POST /api/auth/reset-password
exports.resetPassword = asyncHandler(async (req, res) => {
  const { resetToken, newPassword } = req.body;

  let payload;
  try {
    payload = verifyToken(resetToken);
  } catch {
    throw new AppError('Invalid or expired reset token', 400);
  }
  if (payload.purpose !== 'password_reset') throw new AppError('Invalid or expired reset token', 400);

  const user = await User.findById(payload.sub).select('+password');
  if (!user) throw new AppError('Invalid or expired reset token', 400);

  // Reset tokens are single-use: reject if the password changed after the token was issued
  if (user.passwordChangedAt && Math.floor(user.passwordChangedAt.getTime() / 1000) >= payload.iat) {
    throw new AppError('Invalid or expired reset token', 400);
  }

  user.password = newPassword;
  user.isVerified = true; // owning the mailbox was proven via OTP
  await user.save();

  res.json({ success: true, message: 'Password reset successful. You can now log in.' });
});

// GET /api/auth/me  (protected)
exports.me = (req, res) => res.json({ success: true, user: req.user });
