const router = require('express').Router();
const rateLimit = require('express-rate-limit');
const ctrl = require('../controllers/auth.controller');
const v = require('../validators/auth.validators');
const validate = require('../middleware/validate');
const { protect } = require('../middleware/auth');

// Tighter limit for OTP-sending endpoints (email abuse protection)
const otpLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many OTP requests. Try again later.' },
});

router.post('/register', v.register, validate, ctrl.register);
router.post('/login', v.login, validate, ctrl.login);
router.post('/send-otp', otpLimiter, v.sendOtp, validate, ctrl.sendOtp);
router.post('/resend-otp', otpLimiter, v.sendOtp, validate, ctrl.sendOtp);
router.post('/verify-otp', v.verifyOtp, validate, ctrl.verifyOtp);
router.post('/forgot-password', otpLimiter, v.forgotPassword, validate, ctrl.forgotPassword);
router.post('/reset-password', v.resetPassword, validate, ctrl.resetPassword);
router.get('/me', protect, ctrl.me);

module.exports = router;
