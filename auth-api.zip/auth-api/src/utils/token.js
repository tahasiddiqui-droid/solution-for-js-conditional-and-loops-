const jwt = require('jsonwebtoken');

// purpose: 'access' (normal login) or 'password_reset' (short-lived, issued after OTP check)
exports.signToken = (userId, purpose = 'access', expiresIn = process.env.JWT_EXPIRES_IN || '7d') =>
  jwt.sign({ sub: userId, purpose }, process.env.JWT_SECRET, { expiresIn });

exports.verifyToken = (token) => jwt.verify(token, process.env.JWT_SECRET);
