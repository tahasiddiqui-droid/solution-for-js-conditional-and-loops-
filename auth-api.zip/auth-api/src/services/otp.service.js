const crypto = require('crypto');
const bcrypt = require('bcrypt');
const Otp = require('../models/Otp');
const AppError = require('../utils/AppError');
const sendEmail = require('../utils/sendEmail');

const cfg = () => ({
  expiresMin: Number(process.env.OTP_EXPIRES_MINUTES) || 10,
  maxAttempts: Number(process.env.OTP_MAX_ATTEMPTS) || 5,
  cooldown: Number(process.env.OTP_RESEND_COOLDOWN_SECONDS) || 60,
});

const SUBJECTS = {
  email_verification: 'Verify your email address',
  password_reset: 'Your password reset code',
};

exports.sendOtp = async ({ email, name, purpose }) => {
  const { expiresMin, cooldown } = cfg();

  const existing = await Otp.findOne({ email, purpose });
  if (existing) {
    const wait = cooldown - (Date.now() - existing.lastSentAt.getTime()) / 1000;
    if (wait > 0) {
      throw new AppError(`Please wait ${Math.ceil(wait)} seconds before requesting another OTP`, 429);
    }
  }

  const otp = String(crypto.randomInt(100000, 1000000));
  const otpHash = await bcrypt.hash(otp, 8);

  await Otp.findOneAndUpdate(
    { email, purpose },
    {
      otpHash,
      attempts: 0,
      lastSentAt: new Date(),
      expiresAt: new Date(Date.now() + expiresMin * 60 * 1000),
    },
    { upsert: true, new: true, setDefaultsOnInsert: true }
  );

  const text = `Hi ${name || 'there'},\n\nYour code is ${otp}. It expires in ${expiresMin} minutes.\nIf you did not request this, you can ignore this email.`;
  const html = `<p>Hi ${name || 'there'},</p><p>Your code is <b style="font-size:20px;letter-spacing:3px">${otp}</b></p><p>It expires in ${expiresMin} minutes. If you did not request this, ignore this email.</p>`;

  try {
    await sendEmail({ to: email, subject: SUBJECTS[purpose], text, html });
  } catch (err) {
    await Otp.deleteOne({ email, purpose });
    console.error('Email send failed:', err.message);
    throw new AppError('Could not send OTP email. Please try again later.', 502);
  }
};

exports.verifyOtp = async ({ email, otp, purpose }) => {
  const { maxAttempts } = cfg();
  const record = await Otp.findOne({ email, purpose });

  if (!record || record.expiresAt < new Date()) {
    throw new AppError('Invalid or expired OTP', 400);
  }
  if (record.attempts >= maxAttempts) {
    await Otp.deleteOne({ _id: record._id });
    throw new AppError('Too many incorrect attempts. Please request a new OTP.', 429);
  }

  const ok = await bcrypt.compare(otp, record.otpHash);
  if (!ok) {
    await Otp.updateOne({ _id: record._id }, { $inc: { attempts: 1 } });
    throw new AppError('Invalid or expired OTP', 400);
  }

  await Otp.deleteOne({ _id: record._id }); // single use
};
