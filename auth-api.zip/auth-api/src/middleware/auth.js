const User = require('../models/User');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const { verifyToken } = require('../utils/token');

exports.protect = asyncHandler(async (req, _res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) throw new AppError('Authentication required', 401);

  const payload = verifyToken(token); // throws JsonWebTokenError / TokenExpiredError -> handled globally
  if (payload.purpose !== 'access') throw new AppError('Invalid token', 401);

  const user = await User.findById(payload.sub);
  if (!user) throw new AppError('User no longer exists', 401);

  if (user.passwordChangedAt && Math.floor(user.passwordChangedAt.getTime() / 1000) > payload.iat) {
    throw new AppError('Password was changed. Please log in again.', 401);
  }

  req.user = user;
  next();
});
