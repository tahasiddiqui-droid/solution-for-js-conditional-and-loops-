const AppError = require('../utils/AppError');

exports.notFound = (req, _res, next) => next(new AppError(`Route not found: ${req.method} ${req.originalUrl}`, 404));

exports.errorHandler = (err, _req, res, _next) => {
  let { statusCode = 500, message } = err;

  if (err.name === 'JsonWebTokenError') { statusCode = 401; message = 'Invalid token'; }
  else if (err.name === 'TokenExpiredError') { statusCode = 401; message = 'Token expired'; }
  else if (err.code === 11000) { statusCode = 409; message = 'Duplicate value: resource already exists'; }
  else if (err.name === 'ValidationError') { statusCode = 422; message = Object.values(err.errors).map((e) => e.message).join(', '); }
  else if (err.type === 'entity.parse.failed') { statusCode = 400; message = 'Malformed JSON body'; }

  if (statusCode >= 500) console.error(err);
  if (statusCode >= 500 && process.env.NODE_ENV === 'production' && !err.isOperational) {
    message = 'Internal server error';
  }

  res.status(statusCode).json({
    success: false,
    message,
    ...(process.env.NODE_ENV !== 'production' && statusCode >= 500 && { stack: err.stack }),
  });
};
