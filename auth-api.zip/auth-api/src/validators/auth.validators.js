const { body } = require('express-validator');

const email = body('email')
  .trim()
  .isEmail().withMessage('A valid email is required')
  .normalizeEmail({ gmail_remove_dots: false, gmail_remove_subaddress: false });

const strongPassword = (field) =>
  body(field)
    .isString().withMessage(`${field} is required`)
    .isLength({ min: 8, max: 72 }).withMessage('Password must be 8-72 characters')
    .matches(/[a-z]/).withMessage('Password must contain a lowercase letter')
    .matches(/[A-Z]/).withMessage('Password must contain an uppercase letter')
    .matches(/\d/).withMessage('Password must contain a number');

const purpose = body('purpose')
  .optional()
  .isIn(['email_verification', 'password_reset'])
  .withMessage('purpose must be email_verification or password_reset');

exports.register = [
  body('name').trim().isLength({ min: 2, max: 50 }).withMessage('Name must be 2-50 characters'),
  email,
  strongPassword('password'),
];

exports.login = [email, body('password').isString().notEmpty().withMessage('Password is required')];

exports.sendOtp = [email, purpose];

exports.verifyOtp = [
  email,
  body('otp').trim().matches(/^\d{6}$/).withMessage('OTP must be a 6-digit number'),
  purpose,
];

exports.forgotPassword = [email];

exports.resetPassword = [
  body('resetToken').isString().notEmpty().withMessage('resetToken is required'),
  strongPassword('newPassword'),
];
